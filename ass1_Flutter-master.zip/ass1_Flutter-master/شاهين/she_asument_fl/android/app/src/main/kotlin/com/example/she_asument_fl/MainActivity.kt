package com.example.she_asument_fl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
